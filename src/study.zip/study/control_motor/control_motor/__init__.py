# control_motor package
# __all__ = [...]          # (선택) 공개 모듈 지정
# __version__ = "0.1.0"    # (선택) 버전 정보